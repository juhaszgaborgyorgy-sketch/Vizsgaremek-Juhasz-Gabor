﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace FociVB
{
    class Vilagbajnoksag
    {
        public int Ev { get; set; }
        public string Rendezo { get; set; }
        public string Bajnok { get; set; }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.WriteLine("LABDARÚGÓ-VILÁGBAJNOKSÁGOK");
            Console.WriteLine("=========================");
            Console.WriteLine("Adatok feldolgozása: 1930-2022");

            List<Vilagbajnoksag> vbLista = new List<Vilagbajnoksag>();

            string[] sorok = File.ReadAllLines("focivb.txt");

            foreach (string sor in sorok)
            {
                string[] adatok = sor.Split(';');

                Vilagbajnoksag vb = new Vilagbajnoksag();

                vb.Ev = int.Parse(adatok[0]);
                vb.Rendezo = adatok[1];
                vb.Bajnok = adatok[2];

                vbLista.Add(vb);
            }

            Console.WriteLine("Az adatok beolvasása sikeres!");

            Console.WriteLine(
                "A világbajnokságok száma: "
                + vbLista.Count + " db");

            Console.WriteLine();
            Console.WriteLine("5. feladat");

            Vilagbajnoksag elso = vbLista[0];
            Vilagbajnoksag utolso = vbLista[0];

            foreach (Vilagbajnoksag vb in vbLista)
            {
                if (vb.Ev < elso.Ev)
                {
                    elso = vb;
                }
                if (vb.Ev > utolso.Ev)
                {
                    utolso = vb;
                }
            }

            Console.WriteLine("Első VB: " + elso.Ev + " - " + elso.Rendezo + " (Bajnok: " + elso.Bajnok + ")");
            Console.WriteLine("Utolsó VB: " + utolso.Ev + " - " + utolso.Rendezo + " (Bajnok: " + utolso.Bajnok + ")");

            Console.Write("Kérek egy évszámot: ");
            int keresettEv = int.Parse(Console.ReadLine());

            bool talalat = false;
            foreach (Vilagbajnoksag vb in vbLista)
            {
                if (vb.Ev == keresettEv)
                {
                    Console.WriteLine("Rendező: " + vb.Rendezo + ", Világbajnok: " + vb.Bajnok);
                    talalat = true;
                }
            }

            if (!talalat)
            {
                Console.WriteLine("Ebben az évben nem volt világbajnokság.");
            }

            Console.Write("Kérek egy országnevet: ");
            string keresettOrszag = Console.ReadLine();

            int cimekSzama = 0;
            foreach (Vilagbajnoksag vb in vbLista)
            {
                if (vb.Bajnok.ToLower() == keresettOrszag.ToLower())
                {
                    cimekSzama++;
                }
            }

            Console.WriteLine(keresettOrszag + " világbajnoki címeinek száma: " + cimekSzama + " db");

            for (int i = 0; i < vbLista.Count - 1; i++)
            {
                for (int j = i + 1; j < vbLista.Count; j++)
                {
                    if (vbLista[i].Ev < vbLista[j].Ev)
                    {
                        Vilagbajnoksag csere = vbLista[i];
                        vbLista[i] = vbLista[j];
                        vbLista[j] = csere;
                    }
                }
            }

            foreach (Vilagbajnoksag vb in vbLista)
            {
                Console.WriteLine(vb.Ev + "\t" + vb.Rendezo + "\t" + vb.Bajnok);
            }

            foreach (Vilagbajnoksag vb in vbLista)
            {
                if (vb.Rendezo == vb.Bajnok)
                {
                    Console.WriteLine(vb.Ev + " - " + vb.Rendezo);
                }
            }


            List<string> kimenet = new List<string>();
            foreach (Vilagbajnoksag vb in vbLista)
            {
                kimenet.Add(vb.Ev + ";" + vb.Rendezo + ";" + vb.Bajnok);
            }

            File.WriteAllLines("eredmenyek.txt", kimenet);
            Console.WriteLine("Az adatok mentése sikeres (eredmenyek.txt)!");

            Console.ReadKey();
        }
    }
}