<?php
$eredmeny = "";

if (isset($_GET["nev"])) {
    $nev = trim($_GET["nev"]);

    try {
        $pdo = new PDO(
            "mysql:host=192.168.1.11;dbname=nevnap;charset=utf8mb4",
            "nevnap_osztaly",
            "Birok2027"
        );

        $sql = "SELECT honap, nap FROM nevnap WHERE nev = ?";
        $lekerdezes = $pdo->prepare($sql);
        $lekerdezes->execute([$nev]);

        $talalatok = $lekerdezes->fetchAll(PDO::FETCH_ASSOC);

        if (count($talalatok) > 0) {
            foreach ($talalatok as $sor) {
                $eredmeny .= $sor["honap"] . ". hónap " . $sor["nap"] . ". nap<br>";
            }
        } else {
            $eredmeny = "Nincs ilyen név az adatbázisban!";
        }

    } catch (PDOException $e) {
        $eredmeny = "Adatbázis-kapcsolati hiba!";
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Névnapkereső</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container">
        <h1>Névnapkereső</h1>

        <form method="get">
            <div class="form-group">
                <label for="nev">Keresztnév</label>
                <input type="text" id="nev" name="nev" placeholder="Írj be egy nevet..." required autocomplete="off">
            </div>
            <button type="submit">Keresés</button>
        </form>

        <?php if (!empty($eredmeny)): ?>
            <div class="eredmeny">
                <?php echo $eredmeny; ?>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>