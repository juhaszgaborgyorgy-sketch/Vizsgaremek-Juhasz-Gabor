function szamitas() {
    let indulas = Number(document.getElementById("indulas").value);
    let erkezes = Number(document.getElementById("erkezes").value);

    let menetido = Math.abs(erkezes - indulas);

    let eredmenyDoboz = document.getElementById("eredmeny");

    if (indulas == erkezes) {
        eredmenyDoboz.innerHTML = "<span style='color:red; font-weight:bold;'>Figyelmeztetés: Ugyanazt az állomást választottad ki!</span>";
        eredmenyDoboz.style.display = "block";
    } else {
        let indulasLista = document.getElementById("indulas");
        let erkezesLista = document.getElementById("erkezes");

        let indulasNev = indulasLista.options[indulasLista.selectedIndex].text;
        let erkezesNev = erkezesLista.options[erkezesLista.selectedIndex].text;

        let megallok = Math.abs(erkezesLista.selectedIndex - indulasLista.selectedIndex) - 1;

        let szoveg = "Indulási állomás: " + indulasNev + "<br>";
        szoveg = szoveg + "Érkezési állomás: " + erkezesNev + "<br><br>";
        szoveg = szoveg + "A vonat menetideje: <b>" + menetido + " perc</b><br>";
        szoveg = szoveg + "Megállók a két állomás között: " + megallok;

        if (menetido > 30) {
            szoveg = szoveg + "<br><br><i>Hosszabb utazás</i>";
        }

        eredmenyDoboz.innerHTML = szoveg;
        eredmenyDoboz.style.display = "block";
    }
}