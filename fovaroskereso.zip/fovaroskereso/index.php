<?php
$host = '192.168.1.11';
$dbname = 'foldrajz';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

$dbError = null;
$results = [];
$searched = false;

$query = isset($_GET['query']) ? trim($_GET['query']) : '';
$search_type = isset($_GET['search_type']) ? $_GET['search_type'] : 'orszag';

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    if ($query !== '') {
        $searched = true;

        if ($search_type === 'fovaros') {
            $sql = "SELECT orszag, fovaros FROM orszagok WHERE fovaros LIKE :query";
        } else {
            $sql = "SELECT orszag, fovaros FROM orszagok WHERE orszag LIKE :query";
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute(['query' => '%' . $query . '%']);
        $results = $stmt->fetchAll();
    }

} catch (PDOException $e) {
    $dbError = "Adatbázis kapcsolódási hiba: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Országok és fővárosok</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Országok és fővárosok</h1>

        <?php if ($dbError): ?>
            <div class="alert error">
                <?= htmlspecialchars($dbError) ?>
            </div>
        <?php else: ?>

            <form action="index.php" method="GET" class="search-form">
                <label for="query">Írd be egy ország nevét!</label>

                <div class="input-group">
                    <input type="text" id="query" name="query" value="<?= htmlspecialchars($query) ?>" required>
                    <button type="submit">Keresés</button>
                </div>

                <div class="radio-group">
                    <label>
                        <input type="radio" name="search_type" value="orszag" <?= $search_type !== 'fovaros' ? 'checked' : '' ?>> Ország alapján
                    </label>
                    <label>
                        <input type="radio" name="search_type" value="fovaros" <?= $search_type === 'fovaros' ? 'checked' : '' ?>> Főváros alapján
                    </label>
                </div>
            </form>

            <?php if ($searched): ?>
                <div class="result-box">
                    <?php if (!empty($results)): ?>
                        <?php foreach ($results as $row): ?>
                            <div class="result-subtitle">
                                <?= htmlspecialchars($row['orszag']) ?> fővárosa:
                            </div>
                            <div class="result-capital">
                                <?= htmlspecialchars($row['fovaros']) ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="not-found">A keresett ország nem található!</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        <?php endif; ?>
    </div>
</body>
</html>